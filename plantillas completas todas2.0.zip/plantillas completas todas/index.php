<?php include 'layoust/head.php'; ?> 

    <div class="site-blocks-cover" style="background-image: url(https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/index%20page%20fsw%2FGIFWEB.gif?alt=media&token=1135f174-fd96-4356-b455-d33f9d7a11bd);" data-aos="fade"></div>
    <div class="site-blocks-cover1" style="background-image: url(https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/index%20page%20fsw%2FFORMATO.gif?alt=media&token=4211f69c-50d7-4f28-b830-36eab0b636ec);" data-aos="fade"></div>
    <div class="space"></div>
    <div class="header__menu">
      <a href="https://instagram.com/fsw.universo?r=nametag"><i class="fab fa-instagram"></i></a>
            <ul>
                <p>Sigueme en</p>
                <li><a href="https://instagram.com/fsw.universo?r=nametag">@fsw.universo</a></li>
            </ul>
        </div>

    <div class="gallery-container">
      <div class="gallery-item">
        <img id="gallery-item-index" src="https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/instagram%2FFINAL%20TRES.png?alt=media&token=3b961c94-db75-4b5b-8a45-cd00974fa375">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/instagram%2FFINAL%20DOS.png?alt=media&token=b5680d8a-12d1-4c1c-86cd-b2d45a299f4d">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/instagram%2FFINAL%20UNO.png?alt=media&token=3b40b194-c3de-4b47-b86a-272b95a0339a">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/instagram%2FFINAL%20CUATRO.png?alt=media&token=274c4d09-8766-4130-bf24-c052c021c4af">
      </div>
    </div>

<?php include('./layoust/foot.php'); ?> 